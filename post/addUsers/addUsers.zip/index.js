const AWS = require('aws-sdk');
AWS.config.update({region : "us-east-2"});
const s3 = new AWS.S3();
const Joi = require("joi");

const srcBucket = "accedia-users-avatars";
exports.handler = async (event) => {
    let ddb = new AWS.DynamoDB();  
    let type = event.image.split(";")[0].split("/")[1];

    // let params = {
    //     Bucket: srcBucket,
    //     Key: `${event.username}`, 
    //     Body: event.image,
    //     ContentEncoding: 'base64',
    //     ContentType: `image/${type}` 
    // }

    // s3.upload(params, (err, data) => {
    //     if (err) { return console.log(err) }
        
    //     console.log('Image successfully uploaded with data:');
    //     console.log(data);
    // });

    // Some way we have to give the user through the event
    var params = {
        User : {
            "username" : {
                S : event.username
            },
            "firstName" : {
                S : event.firstName
            },
            "lastName" : {
                S : event.lastName
            },
            "password" : {
                S : event.password
            },
            "email" : {
                S : event.email
            }
        }
    };
    const addingUser = await ddb.putItem(params, (err, result) => {
        if(err){
            console.log(err);
            return {"result" : err};
        }
        console.log("User successfully created");
        return {"result" : "User successfuly created"};
    }).promise();


    return addingUser;
};